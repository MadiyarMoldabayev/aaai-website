# 🚀 Быстрый деплой на Netlify

## Шаг 1: Создайте репозиторий на GitHub

1. Перейдите на https://github.com/new
2. Название репозитория: `aaai-website` (или любое другое)
3. **ВАЖНО**: НЕ ставьте галочки на "Add a README file", "Add .gitignore", "Choose a license"
4. Нажмите "Create repository"

## Шаг 2: Загрузите код в GitHub

Выполните эти команды в терминале (замените `YOUR_USERNAME` на ваш GitHub username):

```bash
cd /Users/moldabaevmadiyar/Downloads/aaai-website

# Добавьте удаленный репозиторий
git remote add origin https://github.com/YOUR_USERNAME/aaai-website.git

# Загрузите код
git branch -M main
git push -u origin main
```

Если репозиторий уже существует, используйте:
```bash
git remote set-url origin https://github.com/YOUR_USERNAME/aaai-website.git
git push -u origin main
```

## Шаг 3: Разверните на Netlify

### Через веб-интерфейс:

1. Перейдите на https://app.netlify.com
2. Войдите или зарегистрируйтесь (можно через GitHub)
3. Нажмите **"Add new site"** → **"Import an existing project"**
4. Выберите **"GitHub"** и авторизуйтесь
5. Выберите репозиторий `aaai-website`
6. Настройки деплоя:
   - **Build command**: (оставьте пустым)
   - **Publish directory**: `.` (точка)
7. Нажмите **"Deploy site"**

### Через Netlify CLI:

```bash
# Установите Netlify CLI (если еще не установлен)
npm install -g netlify-cli

# Войдите в Netlify
netlify login

# В папке проекта
cd /Users/moldabaevmadiyar/Downloads/aaai-website

# Инициализируйте и разверните
netlify init
netlify deploy --prod
```

## Шаг 4: Готово! 🎉

После деплоя вы получите URL вида: `https://random-name-123.netlify.app`

Вы можете:
- Настроить кастомный домен в настройках сайта
- Каждый push в GitHub будет автоматически обновлять сайт

## Альтернатива: Прямая загрузка (без GitHub)

1. Перейдите на https://app.netlify.com/drop
2. Перетащите всю папку `aaai-website` в браузер
3. Дождитесь завершения деплоя

---

**Примечание**: Для автоматического деплоя при каждом изменении рекомендуется использовать GitHub интеграцию.

